<?php

namespace Lem\Page\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    //
}
