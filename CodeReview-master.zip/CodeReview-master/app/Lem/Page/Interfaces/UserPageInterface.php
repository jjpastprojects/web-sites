<?php namespace Lem\Page\Interfaces;



interface UserPageInterface
{


}
