<?php namespace Lem\Page\Interfaces;



interface PageStatusInterface
{


}
