<?php

namespace Lem\Condition;

class Condition
{

    public function __construct($argument1)
    {
        // TODO: write logic here
    }

    public function validateBetweenParentheseNotEmpty($argument1)
    {
        // TODO: write logic here
    }

    public function validateParenthese($argument1)
    {
        // TODO: write logic here
    }

    public function hasFirstAndLastParentheses($argument1)
    {
        // TODO: write logic here
    }

    public function isAndCondition($argument1)
    {
        // TODO: write logic here
    }

    public function splitAndCondition($argument1)
    {
        // TODO: write logic here
    }

    public function isOrCondition($argument1)
    {
        // TODO: write logic here
    }

    public function splitOrCondition($argument1)
    {
        // TODO: write logic here
    }

    public function hasANegativeSign($argument1)
    {
        // TODO: write logic here
    }

    public function enleveNegativeSign($argument1)
    {
        // TODO: write logic here
    }

    public function isValideOperator($argument1)
    {
        // TODO: write logic here
    }

    public function validate($argument1)
    {
        // TODO: write logic here
    }

    public function enleveFirstAndLastParentheses($argument1)
    {
        // TODO: write logic here
    }
}
