<?php namespace Lem\Role\Interfaces;



interface RoleInterface
{


}
