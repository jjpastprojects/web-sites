<?php namespace Lem\Role;

/**
 * to manipilate the pages
 **/
class Role
{

    function __construct()
    {
    }

}
