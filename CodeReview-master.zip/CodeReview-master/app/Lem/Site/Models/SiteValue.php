<?php

namespace Lem\Site\Models;

use Illuminate\Database\Eloquent\Model;

class SiteValue extends Model
{
    //
}
