<?php namespace Lem\Site;

/**
 * to manipilate the pages
 **/
class Site
{

    function __construct()
    {
    }

}
