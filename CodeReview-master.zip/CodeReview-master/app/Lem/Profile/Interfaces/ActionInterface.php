<?php namespace Lem\Profile\Interfaces;

Interface ActionInterface{}
