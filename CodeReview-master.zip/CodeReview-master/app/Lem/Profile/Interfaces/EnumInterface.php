<?php namespace Lem\Profile\Interfaces;

Interface EnumInterface
{
    public function getValuesByVariableId($varId);
}
