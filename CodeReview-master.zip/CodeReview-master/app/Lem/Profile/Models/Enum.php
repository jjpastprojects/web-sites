<?php namespace Lem\Profile\models;

use Illuminate\Database\Eloquent\Model;

class Enum extends Model {

    protected $fillable = ['variable_id', 'values'];

}
