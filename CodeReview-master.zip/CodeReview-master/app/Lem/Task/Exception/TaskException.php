<?php namespace Lem\Task\Exception;

use Exception;


/**
 * the task Exception
 **/
class TaskException extends Exception
{
}
