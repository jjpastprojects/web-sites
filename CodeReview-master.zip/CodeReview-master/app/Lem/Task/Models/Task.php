<?php namespace Lem\Task\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model {

        protected $fillable = ['whenCondition', 'code'];

}
