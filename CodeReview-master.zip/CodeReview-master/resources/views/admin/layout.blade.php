@extends('app')

@section('title')

@stop

@section('content')
    @yield('content')
@stop

