@extends('app')

@section('title')

@stop

@section('content')
    <div class="container">
        <h1>Your Profile Is Complete</h1>
    </div>
@stop

