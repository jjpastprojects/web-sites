<div class="form-group">
<div class="col-md-4 col-md-offset-4 ">
         @include("profile.partials.$type", ['i' => $i])
</div>
</div>

