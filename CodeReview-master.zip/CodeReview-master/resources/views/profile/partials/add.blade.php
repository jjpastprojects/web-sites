<div class="form-group">
    <div class="col-md-6 col-md-offset-4">
        <button id="column_add" type="button" class="btn btn-success">
            {{ Lang::get('column.add') }}
        </button>
    </div>
</div>
