@include('partials.header')

@include('partials.nav')

@yield('content')

@include('partials.footer')
