@extends('emails.default')

@section('title')

@stop

@section('content')
    email
@stop

