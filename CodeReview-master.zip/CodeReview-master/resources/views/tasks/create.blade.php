@extends('layout')

@section('title')

@stop

@section('content')

    {{ Form::open() }}

    {{ Form::close() }}

@stop

