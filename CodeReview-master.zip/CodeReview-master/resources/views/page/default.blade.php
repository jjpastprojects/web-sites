@extends('app')

@section('title')
   @yield('title')
@stop

@section('content')

    <div class="container">
                @yield('content-2')
    </div>

@stop

