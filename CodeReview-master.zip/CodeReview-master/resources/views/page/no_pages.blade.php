@extends('page.default')

@section('title')

@stop

@section('content-2')
        {{ trans('page.no_pages') }}
@stop

