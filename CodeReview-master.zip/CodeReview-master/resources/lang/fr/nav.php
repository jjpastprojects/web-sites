<?php

return [
    'login' => 'Login',
    'register' => 'Register',
    'site-name' => 'Francais Site Name',
];
