<?php
return [
    'page' => 'pages',
    ];
