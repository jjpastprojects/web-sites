<?php

return [
    'no_pages' => 'No Pages',
];
