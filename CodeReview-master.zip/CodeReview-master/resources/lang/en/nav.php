<?php

return [
    'home' => 'home',
    'site-name' => 'Site Name',
    'login' => 'login',
    'register' => 'register',

];
