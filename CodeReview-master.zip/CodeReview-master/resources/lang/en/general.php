<?php

return [
    'new' => 'new',
    'readed' => 'readed',
    'saved' => 'saved',
    'inTrash' => 'trash',
    'set_new_variable' => 'set new variable',
    'show_undefined_variable' => 'show undefined variable',
    'profile' => 'profile',
    'Logout' => 'Logout',
];
