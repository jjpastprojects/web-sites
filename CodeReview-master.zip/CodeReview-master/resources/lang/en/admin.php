<?php
return [
    'all_users' => 'all users',
];
