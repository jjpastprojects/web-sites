my code is in app/Lem
and I try to make every thing a facade, so I make a User
Facade which use a UserRepository which use a UserModels

and I use phpunit to test.

folder I suggest to check
app/Lem
app/Facades
app/Http/Controllers
test/App

